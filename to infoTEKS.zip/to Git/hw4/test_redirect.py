import unittest
from redirect import Redirect
import sys
import io

class Test(unittest.TestCase):
    def setUp(self):
        self.test_file_stream = sys.stdout
        # self.test_file_stream = sys.stderr
        self.redirect = Redirect()

    def test_define_type(self):
        self.assertIsInstance(sys.stdout, io.IOBase)

    def test_is_empty(self):
        self.assertIsNone(self.redirect.stderr)

    def test_redirect(self):
        stdout_file = open('stdout1.txt', 'w')
        stderr_file = open('stderr1.txt', 'w')
        print('the test before Redirect')
        # self.redirect.stdout = sys.stdout
        # self.redirect.stderr = sys.stderr

        with Redirect(stdout=stdout_file, stderr=stderr_file):
            print('Hello stdout1.txt')
            raise Exception('Hello stderr1.txt')

        print('after Redirect')
        # raise Exception('this is stderr')
        # self.assertTrue('the test' in sys.stdout and 'Traceback (most recent call last): File "/home/oleg/python/skillbox/python_advanced/module_05_processes_and_threads/homework/hw4/redirect.py", line 59, in <module> raise Exception(\'Hello stderr.txt\') Exception: Hello stderr.txt' in sys.stderr)
        # self.assertTrue('the test before Redirect' in sys.stdout)
        self.assertTrue('after Redirect' in sys.stdout)

# TODO надо проверить работу контекстного менеджера Redirect - напишите тесты, в которы примените менеджер Redirect,
#  в тестах запишите в оба указанных в мендежере потока данные, а также в оба стандартных поток (до и после менеджера)
#  - то есть сделайте print и выбросите исключение. Потом проверьте в наличие соответствующих данных в соответствующих
#  потоках


if __name__ == '__main__':
    with open('test_results.txt', 'a') as test_file_stream:
        runner = unittest.TextTestRunner(stream=test_file_stream)
        unittest.main(testRunner=runner)
