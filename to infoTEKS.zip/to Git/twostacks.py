class Stack:
    # Стек имитации
    def __init__(self):
        self.items = []
        # Проверить, если стек пуст

    def isEmpty(self):
        return len(self.items) == 0
        # Размер стека

    def size(self):
        return len(self.items)
        # Вернуться к верхнему элементу

    def top(self):
        if not self.isEmpty():
            return self.items[len(self.items) - 1]
        else:
            return None
        #   Стек

    def pop(self):
        if len(self.items) > 0:
            return self.items.pop()
        else:
            print('Стек уже пуст')
            return None
            # Нажмите стек

        def push(self, item):
            self.items.append(item)

class MyStack:
    def __init__(self):
        self.A = Stack()
        self.B = Stack()

    def push(self, data):
        self.A.push(data)

    def pop(self):
        if self.B.isEmpty():
            while not self.A.isEmpty():
                self.B.push(self.A.top())
                self.A.pop()
        first = self.B.top()
        self.B.pop()
        return first


class Queue:
    def __init__(self):
        self.stack1 = []
        self.stack2 = []

    def insert(self, data):
        self.stack1.append(data)

    def pop(self):
        if not self.stack1 and not self.stack2:
            print('queue is empty')
            return
        if not self.stack2:
            while(self.stack1):
                self.stack2.append(self.stack1.pop())
        return self.stack2.pop()

    def showStack(self):
        print('stack1:', self.stack1)
        print('stack2:', self.stack2)

class Queue:
    def __init__(self):
        self.stack1 = []
        self.stack2 = []

    def insert(self, data):
        self.stack1.append(data)

    def showStack(self):
        print('stack1:', self.stack1)
        print('stack2:', self.stack2)

    def pop(self):
        if not self.stack1 and not self.stack2:
            print('queue is empty')
            return

        while self.stack1:
            self.stack2.append(self.stack1.pop())
        return self.stack2.pop()



if __name__ == "__main__":

    queue = Queue()
    queue.insert(1)
    queue.insert(2)
    queue.insert(3)
    queue.insert(4)
    queue.showStack()
    queue.pop()
    queue.pop()
    # queue.pop()
    queue.showStack()
    # s = MyStack()
    # s.push(1)
    # s.push(2)
    # print('Первый элемент очереди:' + str(s.pop()))
    # print('Первый элемент очереди:' + str(s.pop()))