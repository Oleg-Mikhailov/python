import datetime
import subprocess
import configparser
from sys import argv
from os import path
import os, shutil
from glob import glob

class execSQL:
    def __init__(self, configpath):
        self.SQLFilePath, self.sqlFileName, self.password = self.getConfigParams('mysql', configpath)
        self.MySQLCommand - 'mysql -u root --password=\'{}\' < {}'.format(self.password, path.join(self.SQLFilePath,
                                                                          self.sqlFileName))

        @staticmethod
        def getConfigParams(section, configfile):
            config = configparser.ConfigParser()
            with open(configfile, encoding='utf-8-sig') as cnfFile:
                config.read_file(cnfFile)
                SQLFilePath = config.get(section, 'SQLFilePath')
                SQLFileName = config.get(section, 'SQLFileNameBase')
                password = config.get(section, 'password')
                return SQLFilePath, SQLFileName, password

if __name__ == '__main__':
    if len(argv) > 1:
        configpath = argv[1]
        binlogCommand = execSQL(configpath).MySQLBCommand
        result = subprocess.run(binlogCommand, shell=True)
    else:
        print('no config path')


#********************************************************************************************************************

class getSQL:
    def __init__(self, configpath):
        self.sourseDBName, self.targetDBName, self.SQLFilePath, self.sqlFileName, self.indent = self.getConfigParams('mysqlbinlog', configpath)
        self.today = datetime.datetime.today().replace(microsecond=0)
        self._indent = datetime.timedelta(days=self.indent)
        self._date = self.today.__sub__(self._indent)
        self.dateRange = '_' + str(self._date).replace('', '_') + '__' + str(self.today).replace('', '_') + '.'
        self.sqlFileName = self.sqlFileName.replace('.', self.dateRange)
        self.MySQLBinLogCommand = 'mysqlbinlog --start-datetime=\"{}\" --rewrite-db=\"{} -> }{\" --database=\"{}\" ' \
                                  '-f /var/lib/mysql/mysql-bin.[0-9]* > {}'.format(self._date, self.sourseDBName,
                                                self.targetDBName, path.join(self.SQLFilePath, self.sqlFileName))

        @staticmethod
        def getConfigParams(section, configfile):
            config = configparser.ConfigParser()
            with open(configfile, encoding='utf-8-sig') as cnfFile:
                config.read_file(cnfFile)
                sourseDBName = config.get(section, 'sourseDBName')
                targetDBName = config.get(section, 'targetDBName')
                SQLFilePath = config.get(section, 'SQLFilePath')
                SQLFileName = config.get(section, 'SQLFileNameBase')
                indent = config.get(section, 'indent')
                return sourseDBName, targetDBName, SQLFilePath, SQLFileName, int(indent)

if __name__ == '__main__':
    if len(argv) > 1:
        configpath = argv[1]
        binlogCommand = getSQL(configpath).MySQLBinLogCommand
        subprocess.run(binlogCommand, shell=True)
    else:
        print('no config path')

#********************************************************************************************************************


def connect_postgres_table(*log_file_name, dbname, user, password, host, port):
    try:
        with psycopg2.connect(dbname=dbname, user=user, password=password, host=host, port=port) as connection:
            # connection.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
            cursor = connection.cursor(cursor_factory=psycopg2.extras.DiotCursor)
    except Exception as error:
        err_str = '\nОшибка: {} {}'.format(datetime.datetime.today().replace(microsecond=0), str(error))
        if log_file_name:
            with open(log_file_name[0], 'a', encoding='utf-8-sig') as log_file:
                log_file.write(err_str)
        return False
    else:
        return cursor

#********************************************************************************************************************

def connect_mysql_database(user, password, database, host, port):
    with connect(user=user, password=password, database=database, host=host, port=port) as connection:
        cursor = connection.cursor()
        return cursor


#пример запроса из базы
cursor.execute("SELECT o.alias, o.\"shortName\", c.number, c.id, cs.name, c.\"startDate\", c.\"endDate\", c.cost, " \
                "\"paymentMethod\" FROM \"Organizations as o\", \"Contracts\" as c, \"ContractStatuses\" as cs WHERE" \
                " c.\"organizationId\" = o.id and c.\"statusId\" = cs.id")

sql_request = "SELECT service_id, sum(data_amount), sum(data_amount_cost) FROM \"{}\" WHERE alias IN {} AND " \
              "tm_start >= \"{}\" AND tm_stop <= \"{}\"{} GROUP BY service_id".format(data_table, aliases_string,
                date_selected_start, date_selected_stop, filter_str)


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found. Check URL (http://10.185.102.14:5000/state/)'}.__str__().
                                 strip('{\"\'}')), 404)


